# Registre des décisions — V2.1

**Statut :** décisions de conception et règles de qualification. Aucune performance applicative mesurée n'est enregistrée dans cette version initiale.

| ID | Décision | Statut et condition de révision |
|---|---|---|
| D-01 | Local, CPU, hôte 16 Go maximum, mono-utilisateur | Invariant du produit ; ne pas contourner par GPU/cloud/swap soutenu |
| D-02 | Next.js statique + React/PDF.js, FastAPI, SQLite/FTS5, Qdrant | Socle retenu ; changement uniquement sur défaut démontré |
| D-03 | E5-small ONNX CPU INT8 est la baseline | Qualifier qualité, quantification et coût avant gel |
| D-04 | Un seul candidat comparatif : Granite 97M Multilingual R2 issu de l'audit | Essai conditionné à source/artefact officiel vérifiable ; sa non-vérification ne bloque pas E5 |
| D-05 | Docling routé natif / structuré / OCR régional | Couverture régionale, structure et provenance contrôlées ; pas de parsing lourd systématique |
| D-06 | Qwen3.5 4B Q4_K_M Ollama non-thinking | Candidat nominal ; CPU, template, mémoire et qualité à qualifier |
| D-07 | RRF + sélection finale sous contraintes | Invariant : identifiants explicitement visés et scope contrôlés après toutes les coupes |
| D-08 | Budgets de preuves 1 536 / 2 560 / 5 120 selon mode | Paramètres initiaux ; couverture nécessaire et plafond global respectés |
| D-09 | Pause coopérative ; reprise manuelle initiale | Aucun kill nominal de cinq secondes ; auto-reprise uniquement après qualification anti-ping-pong |
| D-10 | Vecteurs mappés, graphe Qdrant RAM/cache au départ | Placement à mesurer ; API et options relues dans le runtime verrouillé |
| D-11 | Texte source immuable, offsets Unicode et révision d'extraction | Invariant de sélection/citation ; fallback de granularité visible |
| D-12 | 200 questions annotées, 100 tenues à l'écart | Périmètre de qualification V2.1 ; dénominateurs/incertitude publiés |
| D-13 | Documents séparés canoniques, brief généré | Aucune édition manuelle divergente de la copie consolidée |

## Décisions de méthode ajoutées en V2.1

| ID | Décision | Statut et vérification |
|---|---|---|
| D-14 | Sources officielles obligatoires avant étude, décision significative, contrat nouveau ou mise à jour | Règle utilisateur ; réutilisation des preuves versionnées valides, revalidation des informations actuelles et des dérives |
| D-15 | Sélection des skills selon tâche, lecture préalable du vrai `SKILL.md`, provenance et permissions contrôlées | Cinq skills projet fournis ; installation native et comportement client non déclarés validés |
| D-16 | Étude SOTA limitée à un enjeu et à un test discriminant | Pas de benchmark brute-force ; pas de remplacement de stack motivé seulement par la nouveauté |

## Arbitrage d'une modification

Identifier le défaut et sa preuve ; définir une hypothèse ; tester un seul changement ciblé ; comparer avant/après à corpus, mode et matériel constants ; vérifier les non-régressions ; enregistrer la décision ; mettre à jour les contrats, paramètres, manifests et tests concernés. Une incompatibilité réelle de version est une raison de modifier un mapping, pas de réécrire le système.

La modification d'un choix qualifiable ne permet pas d'affaiblir un invariant ni de modifier discrètement un seuil de recette. Si le matériel ne passe pas un objectif, conserver le résultat et l'écart. Une donnée manquante n'est ni une mesure nulle ni une réussite par défaut.

Les paramètres initiaux ont un statut `BASELINE_TO_QUALIFY`. Le choix final devient `LOCKED_AFTER_EVIDENCE` uniquement avec référence à un rapport réel. Les caractéristiques du candidat non reconfirmées dans les sources restent `NOT_REVERIFIED`, sans déduction sur son existence.


Pour toute nouvelle entrée, ajouter source officielle/section, version documentée/installée, date de consultation, fait/hypothèse, résultat observé et fichiers affectés selon `RECHERCHE_ET_SKILLS.md`. Les décisions de conception préexistantes ne deviennent pas des résultats techniques validés du seul fait de leur présence dans ce registre.
