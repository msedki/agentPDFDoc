# Adaptateur de lecture — agents Claude Code

Lire [AGENTS.md](AGENTS.md) pour les consignes persistantes de ce dépôt, puis [RECHERCHE_ET_SKILLS.md](RECHERCHE_ET_SKILLS.md) pour toute décision technique significative. Conserver les instructions préexistantes de l'environnement.

Choisir dans [SKILLS.md](SKILLS.md) la compétence correspondant à la tâche et ouvrir son vrai `SKILL.md` ; ne pas charger tous les skills ni le brief consolidé. Consulter les sources officielles actuelles et le contrat de la version réellement installée avant étude, changement ou mise à jour. Tracer source, décision et preuve.

Le fichier présent est un adaptateur de consignes, pas un plugin ni une installation de skills. La découverte native dépend de la version et de la configuration réelles du client. Les références et les skills projet restent canoniques dans ce dépôt.

Ne pas exposer les skills de développement au LLM documentaire local. Ne pas envoyer le corpus privé à un service externe. Ne pas remplacer les instructions existantes de `CLAUDE.md` dans un dépôt déjà utilisé : intégrer ce contenu sans les écraser.
