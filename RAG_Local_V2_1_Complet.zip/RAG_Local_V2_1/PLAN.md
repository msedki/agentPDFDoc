# Plan de réalisation vivant — V2.1

**État de remise :** les documents de réalisation ont été révisés et leurs contrôles documentaires sont séparés. Aucun module applicatif, aucun runtime et aucune performance du poste utilisateur ne sont déclarés terminés.

## Pilotage

États de chantier : `NOT_STARTED`, `READY`, `IN_PROGRESS`, `BLOCKED`, `VERIFIED`. Une vérification possède une preuve ; le simple contenu de ce plan ne la crée pas. L'intégrateur gère contrats communs, migrations, configurations et lockfiles. Les branches prennent des tâches prêtes, sans attendre qu'une autre branche entière soit achevée.

## Graphe de dépendances

```text
A — inspection ciblée + contrats minimaux + environnement
├── B — ingestion/routage/provenance ── Q-PDF
├── C — search/scopes/citations ────── Q-SEARCH
├── D — UI/arbre/PDF/sélection/chat
└── E — qualification/outillage ───── Q-CPU

Premiers résultats B/C/D/E → V — première chaîne verticale réelle
C + E → M — A/B unique d'embedding, seulement si préconditions vérifiées
V + Q-PDF/Q-SEARCH/Q-CPU → R — robustesse, recette et livraison
M → gel du modèle ; ne bloque pas V sous baseline E5
```

Les travaux des agents sont parallèles lorsqu'indépendants. Les essais lourds sur le même PC sont réservés sans concurrence qui invaliderait leurs mesures. Les vérifications précoces sont courtes et discriminantes ; ne pas en faire une étude générale avant de commencer l'intégration.

| ID | Résultat observable | Dépendances minimales | Propriétaire | État initial | Critères |
|---|---|---|---|---|---|
| A | Inventaire CPU/OS/dépôt, contrats Scope/Selection/Citation/Query/Checkpoint, dépendances vérifiées | Accès aux outils | Intégrateur | NOT_STARTED | D01,D10 |
| B | Routes PDF, régions couvertes, provenance canonique et reprise | Contrats version/extraction/bloc | Agent ingestion | NOT_STARTED | D02,D03,D06 |
| C | Exact+BM25+dense, contraintes finales, contexte et vraie génération | Contrats chunks/scope/query | Agent backend/retrieval | NOT_STARTED | D04,D05 |
| D | Trois panneaux, sélection Unicode, citations et budget raster | Contrats API et données d'essai | Agent UI | NOT_STARTED | D06 |
| E | Doctor, fixtures, runners, ressources/offline et scripts | Structure minimale du dépôt | Agent qualité/exploitation | NOT_STARTED | D01,D07,D08,D09 |
| Q-PDF | Difficultés PDF et frontières de fenêtres vérifiées | Premier adaptateur réel B | B + vérificateur | NOT_STARTED | D02,D06 |
| Q-SEARCH | Contre-exemple RRF corrigé et absence de fuite | Premier sélecteur réel C | C + vérificateur | NOT_STARTED | D04,D05 |
| Q-CPU | Modèle réel, mémoire, chargement/prompt/sortie/cache distingués | Runtime local réel E | E | NOT_STARTED | D07 |
| V | Import→extraction→index→question→réponse→citation→surlignage | Première tranche B/C/D + E | Intégrateur | NOT_STARTED | D02,D04,D05,D06 |
| M | Décision d'embedding après essai unique ou impossibilité documentée du candidat | Corpus extrait et E5 fonctionnel | C + E | NOT_STARTED | D10 |
| R | Recette complète, rapport et commandes de livraison réelles | V + résultats de qualification | Intégrateur + vérificateur | NOT_STARTED | D01–D11 |

## Recherche officielle et skills à chaque chantier

Le responsable de chaque chantier applique `RECHERCHE_ET_SKILLS.md`, consulte les sources officielles correspondant à la décision et charge le `SKILL.md` pertinent du registre. A partage l'inventaire d'outils/skills et les vérifications utiles ; B utilise prioritairement la compétence provenance, C la compétence retrieval, D la compétence E2E et E la qualification CPU. Une compétence déjà installée plus appropriée peut être retenue après vérification.

Chaque livraison intermédiaire indique sources/versions consultées, skill réellement lu/utilisé, résultat et modifications de registres nécessaires. L'intégrateur fusionne ces références au lieu de faire refaire les mêmes recherches. Les décisions avec source bloquée sont isolées ; les branches prêtes continuent. D11 accompagne tous les chantiers et la recette finale.

## Propriété des fichiers

B : `services/ingestion/` et tests de parsing. C : modules search/embedding/context/citation de l'API et tests. D : `apps/web/`. E : fixtures, evals et scripts qualité/exploitation. L'intégrateur : contrats partagés, migrations, routes communes, configuration et lockfiles. Adapter à l'existant sans écraser les fichiers d'un autre agent ; worktrees quand disponibles.

Chaque mission déléguée indique objectif, fichiers, contrats, dépendances, test et format de retour. Les mocks sont admis pour des tests de frontière isolés ; ils sont exclus de la preuve V et de la recette E2E.

## Tranche verticale initiale

Un PDF natif français contrôlé comportant une référence, une valeur et une section. Import réel ; extraction et deux index réels ; réponse du vrai modèle local ; ID de preuve enregistré ; clic ouvrant la version/page/bloc corrects. Conserver la trace et les compteurs. Étendre au tableau et à la page mixte sans attendre de finaliser tous les écrans.

## Blocages et arbitrages

Un blocage indique symptôme, preuve, hypothèse, test tenté et prochaine action discriminante. Pendant qu'une dépendance est bloquée, traiter une tâche indépendante prête. Ne pas recréer le composant d'un autre agent. Un candidat d'embedding inaccessible n'oblige pas à suspendre l'ensemble du projet ; poursuivre E5 et tracer l'impossibilité d'A/B.

Un changement de paramètre qualifiable suit `DECISIONS.md`. Pas de recherche ouverte de modèles, pas de réindexation totale après une erreur locale, pas de test lourd répété sans information nouvelle. Les résultats métier nécessitent un corpus autorisé ; ils ne sont pas remplacés par des fixtures présentées comme représentatives.

## Mise à jour

Après résultat substantiel : date, ID de chantier, commit, preuve, mesure, décision et état. Mettre à jour le registre des décisions lorsque nécessaire, puis régénérer le brief. Aucun résultat applicatif n'est prérempli dans ce plan.
