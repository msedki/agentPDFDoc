# Sources officielles et traçabilité — V2.1

**Révision documentaire :** 29 septembre 2026. Les décisions de ce dossier restent des choix de conception, non des résultats certifiés par les éditeurs. Les versions de production doivent être verrouillées séparément ; une documentation sur `main`/`master` ne constitue pas un verrou logiciel.

## Références

| ID | Source officielle | Usage et statut documentaire |
|---|---|---|
| S01 | [Ollama — FAQ](https://docs.ollama.com/faq) | Référence conservée de la baseline : variables, rétention, concurrence et cloud ; vérifier la version de runtime au provisionnement |
| S02 | [Ollama — API chat](https://docs.ollama.com/api/chat) | Reconsultée pour cette V2.1 : flux, options et compteurs ; disponibilité des champs à contrôler au runtime |
| S03 | [Qwen3.5-4B — fiche officielle](https://huggingface.co/Qwen/Qwen3.5-4B) ; [distribution Ollama](https://ollama.com/library/qwen3.5) | Fiche Qwen reconsultée ; artefact Ollama exact, digest et Q4_K_M à contrôler, pas de RAM déduite du téléchargement |
| S04 | [multilingual-e5-small — fiche officielle](https://huggingface.co/intfloat/multilingual-e5-small/blob/main/README.md) | Référence E5 conservée : 384D, limites, préfixes/pooling ; artefact ONNX INT8 à produire ou vérifier |
| S05 | [ONNX Runtime — threading](https://onnxruntime.ai/docs/performance/tune-performance/threading.html) | Référence des threads et du spinning ; vérifier les options de la session réellement créée |
| S06 | [Docling — dépôt officiel](https://github.com/docling-project/docling) | Référence du composant, releases/licences à verrouiller |
| S07 | [Docling — options de pipeline](https://github.com/docling-project/docling/blob/main/docling/datamodel/pipeline_options.py) | Référence générale ; ne pas déduire la compatibilité de la seule branche courante |
| S08 | [Qdrant — configuration officielle](https://github.com/qdrant/qdrant/blob/master/config/config.yaml) ; [API création collection](https://api.qdrant.tech/api-reference/collections/create-collection) | Configuration serveur reconsultée : placement mémoire et dépréciations. Le schéma API de la version installée reste à tester séparément |
| S09 | [Next.js — static exports](https://nextjs.org/docs/app/guides/static-exports) | Référence du mode export ; les fonctionnalités serveur restent hors du profil statique |
| S10 | [Mozilla PDF.js — exemples](https://mozilla.github.io/pdf.js/examples/) | Référence du rendu/viewport ; alignement des sélections et surlignages à tester dans l'application |
| S11 | [SQLite — FTS5](https://sqlite.org/fts5.html) | BM25, tokenizers, triggers et tables externes ; SQL local réellement testé dans ce dossier |
| S12 | [OpenAI Codex — AGENTS.md](https://developers.openai.com/codex/guides/agents-md) | Référence des instructions de dépôt, conservée ; ce dossier ne sélectionne pas un modèle Codex via Markdown |
| S13 | [PyMuPDF — README](https://github.com/pymupdf/PyMuPDF/blob/main/README.md) | Référence de la décision historique de ne pas introduire cette dépendance nominale ; inventorier toutes les licences livrées |
| S14 | [Docling — options avancées](https://github.com/docling-project/docling/blob/main/docs/usage/advanced_options.md) | Reconsultée : voie native sans modèles layout/OCR/table, threads du parseur distincts, artefacts locaux |
| S15 | [Docling — pipeline options v2.131.0](https://github.com/docling-project/docling/blob/v2.131.0/docling/datamodel/pipeline_options.py) | Code versionné reconsulté : OcrMode et voies régionales ; ce tag de référence n'est pas déclaré testé comme installation complète |
| S16 | [Granite 97M Multilingual R2 — candidat de l'audit](https://huggingface.co/ibm-granite/granite-embedding-97m-multilingual-r2) ; [publication IBM citée par l'audit](https://huggingface.co/blog/ibm-granite/granite-embedding-multilingual-r2) | Accès non reconfirmé pendant cette V2.1. Vérifier avant essai ; aucun score ni artefact CPU ne sont présentés comme vérifiés ici |

## Ce qui relève du projet

Les tailles de fragments, top-k, RRF k=60, budgets de tokens, enveloppes mémoire, politiques d'ordonnancement, métriques de recette et choix des composants sont des décisions explicites. Les sources documentent des mécanismes ; elles ne qualifient pas leur combinaison sur le PC utilisateur.

Les calculs 25 000 × 384 × 4, le contre-exemple RRF et les exemples d'offsets Unicode sont des contrôles de référence reproductibles du dossier, pas des benchmarks éditeurs ni des tests du sélecteur applicatif futur.

Une source inaccessible est notée comme telle. Ne pas la remplacer par une information supposée. Les dates et chiffres comparatifs de l'audit non reconfirmés ne sont pas nécessaires à la réalisation de la baseline E5 ; ils ne sont donc pas recopiés comme faits certifiés.

## Procédure de verrouillage

Identifier la version installée ; consulter son schéma officiel ou son code à cette version ; écrire un test de contrat minimal ; enregistrer commande, version, source et résultat ; produire le manifeste réel. Ne jamais inventer une signature, un digest, une option CLI ou un résultat de performance pour rendre un fichier complet.

Les autres dépendances de la stack conservent leurs sources officielles dans les lockfiles et le registre de licences produits au provisionnement. Aucun jeu de poids, fichier de police ou fichier privé n'est distribué avec ce dossier.


## Sources sur les compétences et leur rédaction — vérification V2.1

Consultation : **29 septembre 2026**. Les pages ci-dessous ont été ouvertes pour cette extension. Leur contenu documentaire ne prouve ni l'installation de compétences ni leur comportement dans un client utilisateur.

| ID | Source officielle | Constat utilisé / statut |
|---|---|---|
| S17 | [Agent Skills — Specification](https://agentskills.io/specification) | Format `SKILL.md`, métadonnées, structure et chargement ciblé vérifiés ; notre procédure reste propre au projet |
| S18 | [Anthropic — Skill authoring best practices](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/best-practices) | Principes de descriptions précises, instructions brèves et essais d'usage consultés |
| S19 | [OpenAI — catalogue plugins](https://github.com/openai/plugins) | Catalogue officiel d'exemples ; ne pas supposer que ces plugins sont installés |
| S20 | [OpenAI — ancien catalogue skills](https://github.com/openai/skills) | README consulté : dépôt marqué déprécié et renvoi vers le catalogue plugins ; pas de prescription d'un ancien installateur |
| S21 | [OpenAI — Package your plugin](https://developers.openai.com/plugins/build/plugins) | Documentation d'empaquetage officielle consultée via sa redirection ; aucune installation native effectuée par ce pack |
| S22 | [OpenAI — Build skills](https://developers.openai.com/plugins/build/skills) | Référence officielle actuelle pour structurer une compétence ; exigences du client à vérifier lors de son intégration |
| S23 | [Anthropic — exemples skills](https://github.com/anthropics/skills) | Dépôt officiel consulté ; exemples à tester et licences par artefact ; les skills projet ne sont pas copiés de ce dépôt |

Les URLs directes historiques `developers.openai.com/codex/skills` et `developers.openai.com/codex/guides/agents-md` n'ont pas été relues avec succès lors de cette extension (erreur d'accès). Même limite pour `code.claude.com/docs/en/skills`. Les routes officielles effectivement accessibles sont listées ci-dessus ; ne pas transformer ces échecs en preuve que les fonctionnalités n'existent pas. La référence S12 reste historique, non reconfirmée ici.

Le registre s'enrichit au fil des études selon [RECHERCHE_ET_SKILLS.md](RECHERCHE_ET_SKILLS.md). Il faut enregistrer la date de consultation et la version réelle avant chaque nouvelle décision dépendante, au lieu de présenter cette bibliographie initiale comme une vérification perpétuelle.
